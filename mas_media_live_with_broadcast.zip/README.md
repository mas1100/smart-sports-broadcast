# Mas Media - بث رياضي ذكي مع البث المباشر

مشروع يستخدم React لواجهة تفاعلية بـ 3 صفحات:
- الصفحة الرئيسية
- تحليلات الأداء
- البث المباشر

## طريقة التشغيل

### الواجهة الأمامية (frontend)
```bash
cd frontend
npm install
npm run start
```

### الواجهة الخلفية (backend)
```bash
cd backend
pip install flask
python app.py
```
