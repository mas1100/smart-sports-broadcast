# مشروع البث الرياضي الذكي

واجهة تفاعلية باستخدام React لتحسين تجربة مشاهدة وتحليل الأداء الرياضي.

## المجلدات:
- `frontend/index.js`: واجهة المستخدم (React)
- `backend/app.py`: واجهة خلفية بسيطة (Flask)

## التشغيل:
1. لتشغيل الواجهة:
   - استخدم React عبر Vite أو Create React App
   - انسخ الكود الموجود في `index.js`

2. لتشغيل الخلفية:
   ```bash
   cd backend
   pip install flask
   python app.py
   ```
