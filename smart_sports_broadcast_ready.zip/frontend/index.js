
import React, { useState } from 'react';
import ReactDOM from 'react-dom';

const styles = {
    container: {
        fontFamily: 'Tahoma, sans-serif',
        backgroundColor: '#f7f9fc',
        textAlign: 'right',
        direction: 'rtl',
        padding: '50px',
        color: '#333',
        lineHeight: '1.6',
    },
    navButton: {
        padding: '10px 20px',
        margin: '0 10px',
        backgroundColor: '#007bff',
        color: '#fff',
        border: 'none',
        borderRadius: '6px',
        cursor: 'pointer',
    },
    header: {
        fontSize: '2rem',
        color: '#007bff',
        marginBottom: '20px',
    },
    paragraph: {
        fontSize: '1.1rem',
        marginBottom: '20px',
    },
    list: {
        marginBottom: '20px',
        paddingRight: '20px',
    },
    chartPlaceholder: {
        backgroundColor: '#fff',
        padding: '20px',
        borderRadius: '10px',
        boxShadow: '0 0 10px rgba(0,0,0,0.1)',
        textAlign: 'center',
    }
};

function HomePage({ goToAnalytics }) {
    return (
        <div style={styles.container}>
            <h1 style={styles.header}>البث الرياضي الذكي</h1>
            <p style={styles.paragraph}>
                منصة متطورة تستخدم الذكاء الاصطناعي لتحسين تجربة مشاهدة المباريات وتحليل الأداء الرياضي بشكل لحظي.
            </p>
            <h3>🎯 أهداف المشروع:</h3>
            <ul style={styles.list}>
                <li>تحليل الأداء الرياضي باستخدام الذكاء الاصطناعي</li>
                <li>تعزيز تفاعل الجمهور من خلال واجهات ذكية</li>
                <li>تحسين جودة البث والتفاعل الشخصي</li>
                <li>توفير تجارب مشاهدة لذوي الاحتياجات الخاصة</li>
            </ul>
            <button style={styles.navButton} onClick={goToAnalytics}>📊 عرض التحليلات</button>
        </div>
    );
}

function AnalyticsPage({ goToHome }) {
    return (
        <div style={styles.container}>
            <h1 style={styles.header}>📈 تحليلات الأداء الرياضي</h1>
            <p style={styles.paragraph}>
                يتم جمع البيانات من المباريات بشكل لحظي وتحليلها لتوفير نظرة أعمق حول أداء الفرق واللاعبين.
            </p>
            <div style={styles.chartPlaceholder}>
                🔍 سيتم عرض الرسوم البيانية التفاعلية هنا مثل السرعة، التمريرات، والتمركز.
            </div>
            <br />
            <button style={styles.navButton} onClick={goToHome}>🏠 العودة للصفحة الرئيسية</button>
        </div>
    );
}

function App() {
    const [page, setPage] = useState("home");

    return page === "home" ? (
        <HomePage goToAnalytics={() => setPage("analytics")} />
    ) : (
        <AnalyticsPage goToHome={() => setPage("home")} />
    );
}

ReactDOM.render(<App />, document.getElementById('root'));
